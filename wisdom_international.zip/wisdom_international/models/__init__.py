# -*- coding: utf-8 -*-
# pour pouvoir faire lire son code python creer dans le models il va devoir importer le fichier ici
from . import wisdom_achat
from . import wisdom_planification
from . import wisdom_employe
from . import wisdom_client
from . import wisdom_planification_emp